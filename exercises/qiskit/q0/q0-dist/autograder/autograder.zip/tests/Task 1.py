test = {   'name': 'Task 1',
    'points': 20,
    'suites': [   {   'cases': [   {   'code': '>>> simpleCircuit().num_clbits == 1\nTrue',
                                       'failure_message': 'Number of classical bits does not match expected.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {'code': '>>> simpleCircuit().num_qubits == 1\nTrue', 'failure_message': 'Number of qubits does not match expected.', 'hidden': False, 'locked': False, 'points': 5},
                                   {   'code': '>>> def testMeasurementPerformedSimple():\n'
                                               '...     ops = simpleCircuit().count_ops()\n'
                                               "...     if 'measure' not in ops:\n"
                                               '...         return False\n'
                                               "...     return ops['measure'] == 1\n"
                                               '>>> \n'
                                               '>>> testMeasurementPerformedSimple()\n'
                                               'True',
                                       'failure_message': 'Remember to perform a measurement.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def testProbabilitiesSimple():\n'
                                               '...     qc = simpleCircuit()\n'
                                               "...     job = execute(qc, BasicAer.get_backend('statevector_simulator'), shots=1)\n"
                                               '...     return list(job.result().get_statevector(qc)) == [1,0]\n'
                                               '>>> \n'
                                               '>>> testProbabilitiesSimple()\n'
                                               'True',
                                       'failure_message': 'Got unexpected state.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

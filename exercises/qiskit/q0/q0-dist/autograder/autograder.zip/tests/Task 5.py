test = {   'name': 'Task 5',
    'points': 15,
    'suites': [   {   'cases': [   {'code': '>>> opposites().num_clbits == 2\nTrue', 'failure_message': 'Unexpected number of classical bits.', 'hidden': False, 'locked': False, 'points': 3},
                                   {'code': '>>> opposites().num_qubits == 2\nTrue', 'failure_message': 'Unexpected number of qubits.', 'hidden': False, 'locked': False, 'points': 3},
                                   {   'code': '>>> def testMeasurementsPerformedOpposites():\n'
                                               '...     ops = opposites().count_ops()\n'
                                               "...     if 'measure' not in ops:\n"
                                               '...         return False\n'
                                               "...     return ops['measure'] == 2\n"
                                               '>>> \n'
                                               '>>> testMeasurementsPerformedOpposites()\n'
                                               'True',
                                       'failure_message': 'Measured unexpected state.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def testProbabilitiesOpposites():\n'
                                               '...     qc = opposites().reverse_bits()\n'
                                               "...     job = execute(qc, BasicAer.get_backend('statevector_simulator'), shots=10)\n"
                                               '...     return list(job.result().get_statevector(qc)) == [0, 1, 0, 0]\n'
                                               '>>> \n'
                                               '>>> testProbabilitiesOpposites()\n'
                                               'True',
                                       'failure_message': 'Measured unexpected state.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

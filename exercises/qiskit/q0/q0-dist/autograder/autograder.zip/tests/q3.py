test = {   'name': 'q3',
    'points': 10,
    'suites': [{'cases': [{'code': ">>> '0' in counts and counts['0'] == 468\nTrue", 'hidden': False, 'locked': False, 'points': 10}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

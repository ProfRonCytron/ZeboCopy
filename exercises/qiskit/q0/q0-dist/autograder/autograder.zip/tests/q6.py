test = {   'name': 'q6',
    'points': 15,
    'suites': [   {   'cases': [{'code': ">>> '01' in counts_oppo and counts_oppo['01'] == 468\nTrue", 'hidden': False, 'locked': False, 'points': 15}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

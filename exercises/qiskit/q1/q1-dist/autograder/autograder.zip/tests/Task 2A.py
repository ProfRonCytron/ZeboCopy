test = {   'name': 'Task 2A',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def testAcceptableGateUsage2A():\n'
                                               '...     ops = reverse_a().count_ops()\n'
                                               "...     x = ops['x'] == 2\n"
                                               "...     y = ops['y'] == 1\n"
                                               "...     z = ops['z'] == 1\n"
                                               "...     h = ops['h'] == 1\n"
                                               '...     try:\n'
                                               "...         u = ops['u'] == 1\n"
                                               '...     except KeyError:\n'
                                               '...         u = False\n'
                                               '...         \n'
                                               '...     return all([x,y,z,h,u])\n'
                                               '...     \n'
                                               '>>> testAcceptableGateUsage2A()\n'
                                               'True',
                                       'failure_message': 'Circuit requirements not satisfied, check bullet list.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def testKetZero2A():\n'
                                               '...     qc = reverse_a()\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector([1,0]))\n'
                                               '>>> \n'
                                               '>>> def testKetOne2A():\n'
                                               '...     initial_state = [0,1]\n'
                                               '...     qc = reverse_a(initial_state)\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector([0,1]))\n'
                                               '...     \n'
                                               '>>> testKetZero2A() and testKetOne2A()\n'
                                               'True',
                                       'failure_message': 'Basis states not passing.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def testRandomSimple2A():\n'
                                               '...     c = random.uniform(0, 2*np.pi)\n'
                                               '...     initial_state = [(np.cos(c)), (np.sin(c))]\n'
                                               '...     qc = reverse_a(initial_state)\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector(initial_state))\n'
                                               '...     \n'
                                               '>>> testRandomSimple2A()\n'
                                               'True',
                                       'failure_message': 'Random state not passing.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

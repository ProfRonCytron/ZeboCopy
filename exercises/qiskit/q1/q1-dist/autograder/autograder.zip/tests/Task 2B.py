test = {   'name': 'Task 2B',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def testAcceptableGateUsage2B():\n'
                                               '...     ops = reverse_b().count_ops()\n'
                                               "...     x = ops['x'] == 5\n"
                                               "...     y = ops['y'] == 5\n"
                                               "...     z = ops['z'] == 5\n"
                                               "...     h = ops['h'] == 5\n"
                                               '...     try:\n'
                                               "...         u = ops['u'] == 1\n"
                                               '...     except KeyError:\n'
                                               '...         u = False\n'
                                               '...     return all([x,y,z,h,u])\n'
                                               '...     \n'
                                               '>>> testAcceptableGateUsage2B()\n'
                                               'True',
                                       'failure_message': 'Circuit requirements not satisfied, check bullet list.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def testKetZero2B():\n'
                                               '...     qc = reverse_b()\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector([1,0]))\n'
                                               '>>> \n'
                                               '>>> def testKetOne2B():\n'
                                               '...     initial_state = [0,1]\n'
                                               '...     qc = reverse_b(initial_state)\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector([0,1]))\n'
                                               '...     \n'
                                               '>>> testKetZero2B() and testKetOne2B()\n'
                                               'True',
                                       'failure_message': 'Basis states not passing.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def testRandomSimple2B():\n'
                                               '...     c = random.uniform(0, 2*np.pi)\n'
                                               '...     initial_state = [(np.cos(c)), (np.sin(c))]\n'
                                               '...     qc = reverse_b(initial_state)\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     sv = Statevector.from_instruction(qc)\n'
                                               '...     return sv.equiv(Statevector(initial_state))\n'
                                               '...     \n'
                                               '>>> testRandomSimple2B()\n'
                                               'True',
                                       'failure_message': 'Random state not passing.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

test = {   'name': 'Task 1',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> qc_pauli_z().num_clbits == 1 and qc_pauli_z().num_qubits == 1\nTrue',
                                       'failure_message': 'Incorrect number of qubits or classical bits.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def testNoQiskitZGate():\n'
                                               '...     ops = qc_pauli_z().count_ops()\n'
                                               "...     return 'z' not in ops\n"
                                               '...     \n'
                                               '>>> def testInitialState():\n'
                                               '...     try:\n'
                                               "...         num_initializations = qc_pauli_z().count_ops()['initialize']\n"
                                               '...     except KeyError:\n'
                                               '...         return False\n'
                                               '...     else:\n'
                                               '...         return num_initializations == 1\n'
                                               '...     \n'
                                               '>>> def testMeasurementPerformed():\n'
                                               '...     try:\n'
                                               "...         num_measurements = qc_pauli_z().count_ops()['measure']\n"
                                               '...     except KeyError:\n'
                                               '...         return False\n'
                                               '...     else:\n'
                                               '...         return num_measurements == 1\n'
                                               '...     \n'
                                               '>>> testMeasurementPerformed() and testNoQiskitZGate() and testInitialState()\n'
                                               'True',
                                       'failure_message': 'Circuit requirements not satisfied, see bullet list.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def testRandomInitialState():\n'
                                               "...     # let's choose something interesting as our initial state!\n"
                                               '...     c = random.uniform(0, 2*np.pi)\n'
                                               '...     initial_state = [(np.cos(c)), (np.sin(c))]\n'
                                               '...     pauli_z_matrix = np.array(\n'
                                               '...                                 [[1, 0],\n'
                                               '...                                  [0,-1]]\n'
                                               '...                              )\n'
                                               '...     \n'
                                               '...     qc = qc_pauli_z(initial_state)\n'
                                               '...     qc.remove_final_measurements()\n'
                                               '...     result_sv = Statevector.from_instruction(qc)\n'
                                               '...     \n'
                                               '...     return result_sv.equiv(Statevector(pauli_z_matrix.dot(initial_state)))\n'
                                               '>>> \n'
                                               '>>> testRandomInitialState()\n'
                                               'True',
                                       'failure_message': 'Incorrect state returned.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
